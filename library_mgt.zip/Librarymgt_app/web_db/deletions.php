<?php

    require_once 'connection.php';

    class deletions {

        function deleteFrom_account($account_id) {
            $db = new dbconnection();
            $con = $db->openconnection();
            $smt = $con->prepare(" DELETE FROM account where account_id =:account_id");
            $smt->bindValue(':account_id', $account_id, PDO::PARAM_STR);
            $smt->execute();
            echo 'Record removed succefully';
        }

        function deleteFrom_account_category($account_category_id) {
            $db = new dbconnection();
            $con = $db->openconnection();
            $smt = $con->prepare(" DELETE FROM account_category where account_category_id =:account_category_id");
            $smt->bindValue(':account_category_id', $account_category_id, PDO::PARAM_STR);
            $smt->execute();
            echo 'Record removed succefully';
        }

        function deleteFrom_profile($profile_id) {
            $db = new dbconnection();
            $con = $db->openconnection();
            $smt = $con->prepare(" DELETE FROM profile where profile_id =:profile_id");
            $smt->bindValue(':profile_id', $profile_id, PDO::PARAM_STR);
            $smt->execute();
            echo 'Record removed succefully';
        }

        function deleteFrom_image($image_id) {
            $db = new dbconnection();
            $con = $db->openconnection();
            $smt = $con->prepare(" DELETE FROM image where image_id =:image_id");
            $smt->bindValue(':image_id', $image_id, PDO::PARAM_STR);
            $smt->execute();
            echo 'Record removed succefully';
        }

        function deleteFrom_book($book_id) {
            $db = new dbconnection();
            $con = $db->openconnection();
            $smt = $con->prepare(" DELETE FROM book where book_id =:book_id");
            $smt->bindValue(':book_id', $book_id, PDO::PARAM_STR);
            $smt->execute();
            echo 'Record removed succefully';
        }

        function deleteFrom_borrow($borrow_id) {
            $db = new dbconnection();
            $con = $db->openconnection();
            $smt = $con->prepare(" DELETE FROM borrow where borrow_id =:borrow_id");
            $smt->bindValue(':borrow_id', $borrow_id, PDO::PARAM_STR);
            $smt->execute();
            echo 'Record removed succefully';
        }

        function deleteFrom_return($return_id) {
            $db = new dbconnection();
            $con = $db->openconnection();
            $smt = $con->prepare(" DELETE FROM returned_bk where return_id =:return_id");
            $smt->bindValue(':return_id', $return_id, PDO::PARAM_STR);
            $smt->execute();
            echo 'Record removed succefully';
        }

    }
    