<?php

    class new_values {

        function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
                $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_account_category($name) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
                $stm->execute(array(':account_category_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
                $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_image($path) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into image values(:image_id, :path)");
                $stm->execute(array(':image_id' => 0, ':path' => $path
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_book($entry_date, $User, $book_title, $publisher, $pub_date, $pub_place, $author, $status) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into book values(:book_id, :entry_date,  :User,  :book_title,  :publisher,  :pub_date,  :pub_place,  :author, :status)");
                $stm->execute(array(':book_id' => 0, ':entry_date' => $entry_date, ':User' => $User, ':book_title' => $book_title, ':publisher' => $publisher, ':pub_date' => $pub_date, ':pub_place' => $pub_place, ':author' => $author, ':status' => $status
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_borrow($entry_date, $User, $book, $borrower, $return_date) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into borrow values(:borrow_id, :entry_date,  :User,  :book, :borrower, :return_date)");
                $stm->execute(array(':borrow_id' => 0, ':entry_date' => $entry_date, ':User' => $User, ':book' => $book, ':borrower' => $borrower, ':return_date' => $return_date));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_return($entry_date, $User, $book, $borrower) {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into returned_bk values(:return_id, :entry_date,  :User,  :book,  :borrower)");
                $stm->execute(array(':return_id' => 0, ':entry_date' => $entry_date, ':User' => $User, ':book' => $book, ':borrower' => $borrower));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

    }
    