<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  <meta name="viewport" content="width=device-width, initial scale=1.0"/>    </head>
    <body class="home_body">
        <?php
            include 'header_menu.php';
        ?>

        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>        

        <div class="parts full_center_two_h x_height_two_fifty" id="home_bg">
            <div class="login_incenter">
                Login
            </div>

        </div>
        <div class="parts sixty_centered " id="child_reader">
            <a href="login.php">
                <div class="parts off no_paddin_shade_no_Border no_shade_noBorder push_right "id="login" style="height: 100px; width: 100px;background-image: url('web_images/login.PNG');background-size: 100%;background-repeat: no-repeat">


                </div></a>
        </div>
        <div class="parts eighty_centered off footer">
            Copyrights <?php echo date("Y"); ?>
            <div class="fb-share-button" data-href="https://www.codeguru-pro.net" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.codeguru-pro.net%2Ftests%2Findex.php&amp;src=sdkpreparse">Share</a></div>        </div>    
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script>
            $('#login').show(1000).animate({marginTop: '70px'}).animate({marginLeft: '-80px'});
        </script>

    </body>
</html>
