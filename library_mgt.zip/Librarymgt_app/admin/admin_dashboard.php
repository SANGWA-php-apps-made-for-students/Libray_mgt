<?php
    session_start();
?>
<html>
    <head>
        <title>Admin dashboard</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php require_once './admin_header.php'; ?>
        <div class="parts eighty_centered datalist_box">
            <h1>
                <?php echo 'Dear ' . $_SESSION['names'] . ' , ' ?>
                Welcome to Libray Management system  </h1>
            <h2></h2>
        </div>
        <div class="parts eighty_centered no_paddin_shade_no_Border">

            <div class="parts no_paddin_shade_no_Border welcome_pic">

            </div>
            <div class="parts no_paddin_shade_no_Border top_off_x welcome_text">
                Choose from the menu above to continue
            </div>
        </div>
    </body>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
    <script src="../web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>
    <script>
        users_menuLink();
        function users_menuLink() {
            $('#borrower_menu_link').click(function () {
                var borrower_menu_link = 'c';
                $.post('handler.php', {borrower_menu_link: borrower_menu_link}, function (data) {

                }).complete(function () {
                    window.location.reload();
                    window.location.replace('new_account.php');

                });
            });
            $('#librarian_menu_link').click(function () {
                var librarian_menu_link = 'c';
                $.post('handler.php', {librarian_menu_link: librarian_menu_link}, function (data) {

                }).complete(function () {
                    window.location.reload();
                    window.location.replace('new_account.php');
                });

            });
        }
        $('.welcome_pic').delay(400).show('slide', {direction: 'left'}, 700, function () {
            $('.welcome_text').show('slide', {direction: 'left'}, 600);
        });
    </script>
</html>
