<div class="parts  eighty_centered " style="background-color: #d17f44;">          
    <div class="parts  no_paddin_shade_no_Border xxx_titles" id="my_header">
        Library management system
    </div>
</div>  
<?php
    if ($_SESSION['cat'] == 'library' || $_SESSION['cat'] == 'admin') {
        ?>
        <div class="parts menu eighty_centered">
            <a href="admin_dashboard.php">Dashboard </a>
            <a href="#" id="borrower_menu_link">Borrower </a>
            <a href="#" id="librarian_menu_link">Librarian </a>
            <!--<a href="new_profile.php">profile</a>-->
            <a href="new_book.php">book</a>
            <a href="new_borrow.php">borrow</a>
            <a href="new_return.php">return</a>
            <a href="Report.php">Report</a>
            <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="../logout.php">Logout</a>
            </div>
        </div>
        <?php
    } else {
        ?>
        <div class="parts menu eighty_centered">
            <a href="admin_dashboard.php">Dashboard </a>
            <a href="#" id="borrower_menu_link">My profile </a>

            <a href="new_book.php">Available books</a>
            <a href="new_borrow.php">My borrow</a>

            <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="../logout.php">Logout</a>
            </div>
        </div>
        <?php
    }
?>


<div class="parts book_left_gif">

</div>
<div class="parts book_right_gif">

</div>
