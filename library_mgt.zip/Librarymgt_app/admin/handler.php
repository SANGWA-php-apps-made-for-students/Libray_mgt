<?php

    session_start();

    if (isset($_POST['cbo_account_category'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
        return $id;
    }
    if (isset($_POST['cbo_profile'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
        return $id;
    }
    if (isset($_POST['cbo_image'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
        return $id;
    }
    if (isset($_POST['cbo_book'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_book_id_by_book_name($_POST['cbo_book']);
        return $id;
    }

    if (isset($_POST['table_to_update'])) {
        $id_upd = $_POST['id_update'];
        $table_upd = $_POST['table_to_update'];
        $pref = 'upd_';
        $sufx = $table_upd;
        $_SESSION['table_to_update'] = $table_upd;
        $_SESSION['id_upd'] = $id_upd;
        echo $_SESSION['id_upd'];
    }


//The Delete from account
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_account($id);
    }
//The Delete from account_category
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_account_category($id);
    }
//The Delete from profile
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_profile($id);
    }
//The Delete from image
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_image($id);
    }
//The Delete from book
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'book') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_book($id);
    }
//The Delete from borrow
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'borrow') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_borrow($id);
    }
//The Delete from return
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'return') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_return($id);
    }
    if (isset($_POST['pagination_n'])) {
        $_SESSION['pagination_n'] = $_POST['pagination_n'];
        $_SESSION['paginated_page'] = $_POST['paginated_page'];
        echo $_SESSION['paginated_page'];
    }
    if (isset($_POST['page_no_iteml'])) {
        unset($_SESSION['pagination_n']);
        $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
        $_SESSION['paginated_page'] = $_POST['paginated_page'];
        echo $_SESSION['page_no_iteml'];
    }
    if (filter_has_var(INPUT_POST, 'borrower_menu_link')) {
        $_SESSION['users_menu_link'] = 'borrower';
    }
    if (filter_has_var(INPUT_POST, 'librarian_menu_link')) {
        $_SESSION['users_menu_link'] = 'library';
    }