<div class="parts  full_center_two_h no_paddin_shade_no_Border reverse_border  heit_free ">     
    <div class="parts  margin_free no_shade_noBorder xxx_titles" style="text-align: center; height: 65px;padding: 2px;">
        Library Management System
        <div class="parts no_paddin_shade_no_Border  push_right" style="margin-right: 40%;font-size: 14px;">

            <a href="login.php">Login</a>

        </div>
    </div>
</div>    
<div class="parts menu off full_center_two_h">

    <a href="index.php">Home</a>
    <a href="#">About us</a>
    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>
    </div>
</div>
