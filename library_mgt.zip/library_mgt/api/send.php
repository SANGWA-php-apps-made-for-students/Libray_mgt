<?php

//This send data to android

if (isset($_POST['get_account'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from account   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_account_category'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from account_category   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_profile'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from profile   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_image'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from image   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_book'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from book   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_borrow'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from borrow   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
if (isset($_POST['get_return'])) {
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select * from return   ";
    foreach ($db->query($sql) as $row) {
        $output[] = $row;
    }
    print json_encode($output);
}
