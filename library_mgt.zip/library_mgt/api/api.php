<?php
require_once('../web_db/new_values.php');
 
if (isset($_POST['new_account'])) {

$new_account = new new_values();
$account_category = $_POST['account_category'];$date_created = $_POST['date_created'];$profile = $_POST['profile'];$username = $_POST['username'];$password = $_POST['password'];$is_online = $_POST['is_online'];
$new_account->new_account($account_category,$date_created,$profile,$username,$password,$is_online);
 if (isset($res)) {
        $json['success'] = 'account added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'account not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_account_category'])) {

$new_account_category = new new_values();
$name = $_POST['name'];
$new_account_category->new_account_category($name);
 if (isset($res)) {
        $json['success'] = 'account_category added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'account_category not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_profile'])) {

$new_profile = new new_values();
$dob = $_POST['dob'];$name = $_POST['name'];$last_name = $_POST['last_name'];$gender = $_POST['gender'];$telephone_number = $_POST['telephone_number'];$email = $_POST['email'];$residence = $_POST['residence'];$image = $_POST['image'];
$new_profile->new_profile($dob,$name,$last_name,$gender,$telephone_number,$email,$residence,$image);
 if (isset($res)) {
        $json['success'] = 'profile added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'profile not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_image'])) {

$new_image = new new_values();
$path = $_POST['path'];
$new_image->new_image($path);
 if (isset($res)) {
        $json['success'] = 'image added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'image not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_book'])) {

$new_book = new new_values();
$entry_date = $_POST['entry_date'];$User = $_POST['User'];$book_title = $_POST['book_title'];$publisher = $_POST['publisher'];$pub_date = $_POST['pub_date'];$pub_place = $_POST['pub_place'];$author = $_POST['author'];
$new_book->new_book($entry_date,$User,$book_title,$publisher,$pub_date,$pub_place,$author);
 if (isset($res)) {
        $json['success'] = 'book added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'book not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_borrow'])) {

$new_borrow = new new_values();
$entry_date = $_POST['entry_date'];$User = $_POST['User'];$book = $_POST['book'];
$new_borrow->new_borrow($entry_date,$User,$book);
 if (isset($res)) {
        $json['success'] = 'borrow added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'borrow not added : ' ;
        echo json_encode($json);
    }
}
if (isset($_POST['new_return'])) {

$new_return = new new_values();

$new_return->new_return();
 if (isset($res)) {
        $json['success'] = 'return added : ' ;
        echo json_encode($json);
    } else {
        $json['success'] = 'return not added : ' ;
        echo json_encode($json);
    }
}
