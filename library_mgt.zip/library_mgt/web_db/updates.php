<?php

require_once 'connection.php';
class updates{

 function update_account( $account_category, $date_created, $profile, $username, $password, $is_online,$account_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
$stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online ,$account_id ));

}
 function update_account_category( $name,$account_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
$stmt->execute(array($name ,$account_category_id ));

}
 function update_profile( $dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
$stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image ,$profile_id ));

}
 function update_image( $path,$image_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
$stmt->execute(array($path ,$image_id ));

}
 function update_book( $entry_date, $User, $book_title, $publisher, $pub_date, $pub_place, $author, $status,$book_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE book set 
entry_date= ?, User= ?, book_title= ?, publisher= ?, pub_date= ?, pub_place= ?, author= ?, status= ? WHERE book_id=?");
$stmt->execute(array($entry_date, $User, $book_title, $publisher, $pub_date, $pub_place, $author, $status ,$book_id ));

}
 function update_borrow( $entry_date, $User, $book,$borrow_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE borrow set 
entry_date= ?, User= ?, book= ? WHERE borrow_id=?");
$stmt->execute(array($entry_date, $User, $book ,$borrow_id ));

}
 function update_return( $entry_date, $User, $book, $borrower,$return_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE return set 
entry_date= ?, User= ?, book= ?, borrower= ? WHERE return_id=?");
$stmt->execute(array($entry_date, $User, $book, $borrower ,$return_id ));

}

}

