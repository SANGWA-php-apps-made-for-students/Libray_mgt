<?php
    require_once '../web_db/connection.php';

    class multi_values {

        function list_account($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> account </td>
                        <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['account_id']; ?>
                        </td>
                        <td class="account_category_id_cols account " title="account" >
                            <?php echo $this->_e($row['account_category']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_created']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['profile']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['username']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['password']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['is_online']); ?>
                        </td>


                        <td>
                            <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="account_id"  data-table="
                               <?php echo $row['account_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="account_update_link" style="color: #000080;" value="
                               <?php echo $row['account_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_account_account_category($id) {

                $db = new dbconnection();
                $sql = "select   account.account_category from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['account_category'];
                echo $field;
            }

            function get_chosen_account_date_created($id) {

                $db = new dbconnection();
                $sql = "select   account.date_created from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_created'];
                echo $field;
            }

            function get_chosen_account_profile($id) {

                $db = new dbconnection();
                $sql = "select   account.profile from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['profile'];
                echo $field;
            }

            function get_chosen_account_username($id) {

                $db = new dbconnection();
                $sql = "select   account.username from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['username'];
                echo $field;
            }

            function get_chosen_account_password($id) {

                $db = new dbconnection();
                $sql = "select   account.password from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['password'];
                echo $field;
            }

            function get_chosen_account_is_online($id) {

                $db = new dbconnection();
                $sql = "select   account.is_online from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['is_online'];
                echo $field;
            }

            function All_account() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  account_id   from account";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_account() {
                $con = new dbconnection();
                $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_id'];
                return $first_rec;
            }

            function get_last_account() {
                $con = new dbconnection();
                $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_id'];
                return $first_rec;
            }

            function list_account_category($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from account_category";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> account_category </td>
                        <td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['account_category_id']; ?>
                        </td>
                        <td class="name_id_cols account_category " title="account_category" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="account_category_id"  data-table="
                               <?php echo $row['account_category_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="account_category_update_link" style="color: #000080;" value="
                               <?php echo $row['account_category_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_account_category_name($id) {

                $db = new dbconnection();
                $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_category_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_account_category() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  account_category_id   from account_category";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_account_category() {
                $con = new dbconnection();
                $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_category_id'];
                return $first_rec;
            }

            function get_last_account_category() {
                $con = new dbconnection();
                $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_category_id'];
                return $first_rec;
            }

            function list_profile($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from profile";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> profile </td>
                        <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['profile_id']; ?>
                        </td>
                        <td class="dob_id_cols profile " title="profile" >
                            <?php echo $this->_e($row['dob']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['gender']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['telephone_number']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['email']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['residence']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['image']); ?>
                        </td>


                        <td>
                            <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                               <?php echo $row['profile_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="profile_update_link" style="color: #000080;" value="
                               <?php echo $row['profile_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_profile_dob($id) {

                $db = new dbconnection();
                $sql = "select   profile.dob from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['dob'];
                echo $field;
            }

            function get_chosen_profile_name($id) {

                $db = new dbconnection();
                $sql = "select   profile.name from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function get_chosen_profile_last_name($id) {

                $db = new dbconnection();
                $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['last_name'];
                echo $field;
            }

            function get_chosen_profile_gender($id) {

                $db = new dbconnection();
                $sql = "select   profile.gender from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['gender'];
                echo $field;
            }

            function get_chosen_profile_telephone_number($id) {

                $db = new dbconnection();
                $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['telephone_number'];
                echo $field;
            }

            function get_chosen_profile_email($id) {

                $db = new dbconnection();
                $sql = "select   profile.email from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['email'];
                echo $field;
            }

            function get_chosen_profile_residence($id) {

                $db = new dbconnection();
                $sql = "select   profile.residence from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['residence'];
                echo $field;
            }

            function get_chosen_profile_image($id) {

                $db = new dbconnection();
                $sql = "select   profile.image from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['image'];
                echo $field;
            }

            function All_profile() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  profile_id   from profile";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_profile() {
                $con = new dbconnection();
                $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function get_last_profile() {
                $con = new dbconnection();
                $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function list_image($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from image";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> image </td>
                        <td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['image_id']; ?>
                        </td>
                        <td class="path_id_cols image " title="image" >
                            <?php echo $this->_e($row['path']); ?>
                        </td>


                        <td>
                            <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="image_id"  data-table="
                               <?php echo $row['image_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="image_update_link" style="color: #000080;" value="
                               <?php echo $row['image_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_image_path($id) {

                $db = new dbconnection();
                $sql = "select   image.path from image where image_id=:image_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':image_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['path'];
                echo $field;
            }

            function All_image() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  image_id   from image";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_image() {
                $con = new dbconnection();
                $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['image_id'];
                return $first_rec;
            }

            function get_last_image() {
                $con = new dbconnection();
                $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['image_id'];
                return $first_rec;
            }

            function list_book($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from book";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> book </td>
                        <td> Entry Date </td><td> User </td><td> Book Title </td><td> Publisher </td><td> Publication Date </td><td> Publication place </td><td> Author </td><td> Status </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['book_id']; ?>
                        </td>
                        <td class="entry_date_id_cols book " title="book" >
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['book_title']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['publisher']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['pub_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['pub_place']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['author']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['status']); ?>
                        </td>


                        <td>
                            <a href="#" class="book_delete_link" style="color: #000080;" data-id_delete="book_id"  data-table="
                               <?php echo $row['book_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="book_update_link" style="color: #000080;" value="
                               <?php echo $row['book_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_book_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   book.entry_date from book where book_id=:book_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':book_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_book_User($id) {

                $db = new dbconnection();
                $sql = "select   book.User from book where book_id=:book_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':book_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function get_chosen_book_book_title($id) {

                $db = new dbconnection();
                $sql = "select   book.book_title from book where book_id=:book_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':book_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['book_title'];
                echo $field;
            }

            function get_chosen_book_publisher($id) {

                $db = new dbconnection();
                $sql = "select   book.publisher from book where book_id=:book_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':book_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['publisher'];
                echo $field;
            }

            function get_chosen_book_pub_date($id) {

                $db = new dbconnection();
                $sql = "select   book.pub_date from book where book_id=:book_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':book_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['pub_date'];
                echo $field;
            }

            function get_chosen_book_pub_place($id) {

                $db = new dbconnection();
                $sql = "select   book.pub_place from book where book_id=:book_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':book_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['pub_place'];
                echo $field;
            }

            function get_chosen_book_author($id) {

                $db = new dbconnection();
                $sql = "select   book.author from book where book_id=:book_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':book_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['author'];
                echo $field;
            }

            function get_chosen_book_status($id) {

                $db = new dbconnection();
                $sql = "select   book.status from book where book_id=:book_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':book_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['status'];
                echo $field;
            }

            function All_book() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  book_id   from book";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_book() {
                $con = new dbconnection();
                $sql = "select book.book_id from book
                    order by book.book_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['book_id'];
                return $first_rec;
            }

            function get_last_book() {
                $con = new dbconnection();
                $sql = "select book.book_id from book
                    order by book.book_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['book_id'];
                return $first_rec;
            }

            function list_borrow($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from borrow";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> borrow </td>
                        <td> Entry Date </td><td> User </td><td> Book </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['borrow_id']; ?>
                        </td>
                        <td class="entry_date_id_cols borrow " title="borrow" >
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['book']); ?>
                        </td>


                        <td>
                            <a href="#" class="borrow_delete_link" style="color: #000080;" data-id_delete="borrow_id"  data-table="
                               <?php echo $row['borrow_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="borrow_update_link" style="color: #000080;" value="
                               <?php echo $row['borrow_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_borrow_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   borrow.entry_date from borrow where borrow_id=:borrow_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':borrow_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_borrow_User($id) {

                $db = new dbconnection();
                $sql = "select   borrow.User from borrow where borrow_id=:borrow_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':borrow_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function get_chosen_borrow_book($id) {

                $db = new dbconnection();
                $sql = "select   borrow.book from borrow where borrow_id=:borrow_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':borrow_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['book'];
                echo $field;
            }

            function All_borrow() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  borrow_id   from borrow";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_borrow() {
                $con = new dbconnection();
                $sql = "select borrow.borrow_id from borrow
                    order by borrow.borrow_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['borrow_id'];
                return $first_rec;
            }

            function get_last_borrow() {
                $con = new dbconnection();
                $sql = "select borrow.borrow_id from borrow
                    order by borrow.borrow_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['borrow_id'];
                return $first_rec;
            }

            function list_return($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from return";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> return </td>
                        <td> Entry Date </td><td> User </td><td> Book </td><td> borrower </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['return_id']; ?>
                        </td>
                        <td class="entry_date_id_cols return " title="return" >
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['book']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['borrower']); ?>
                        </td>


                        <td>
                            <a href="#" class="return_delete_link" style="color: #000080;" data-id_delete="return_id"  data-table="
                               <?php echo $row['return_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="return_update_link" style="color: #000080;" value="
                               <?php echo $row['return_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_return_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   return.entry_date from return where return_id=:return_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':return_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_return_User($id) {

                $db = new dbconnection();
                $sql = "select   return.User from return where return_id=:return_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':return_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function get_chosen_return_book($id) {

                $db = new dbconnection();
                $sql = "select   return.book from return where return_id=:return_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':return_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['book'];
                echo $field;
            }

            function get_chosen_return_borrower($id) {

                $db = new dbconnection();
                $sql = "select   return.borrower from return where return_id=:return_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':return_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['borrower'];
                echo $field;
            }

            function All_return() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  return_id   from return";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_return() {
                $con = new dbconnection();
                $sql = "select return.return_id from return
                    order by return.return_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['return_id'];
                return $first_rec;
            }

            function get_last_return() {
                $con = new dbconnection();
                $sql = "select return.return_id from return
                    order by return.return_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['return_id'];
                return $first_rec;
            }

            function get_account_category_in_combo() {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select account_category.account_category_id,   account_category.name from account_category";
                ?>
            <select class="textbox cbo_account_category"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_profile_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select profile.profile_id,   profile.name from profile";
            ?>
            <select class="textbox cbo_profile"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_image_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select image.image_id,   image.name from image";
            ?>
            <select class="textbox cbo_image"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_book_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select book.book_id,   book.name from book";
            ?>
            <select class="textbox cbo_book"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['book_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_borrower_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select borrower.borrower_id,   borrower.name from borrower";
            ?>
            <select class="textbox cbo_borrower"><option></option>
                    <?php
                    foreach ($db->query($sql) as $row) {
                        echo "<option value=" . $row['borrower_id'] . ">" . $row['name'] . " </option>";
                    }
                    ?>
            </select>
            <?php
        }

        function _e($string) {
            echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
        }

    }
    